import Profile from "@/pages/Profile";

export default function ProfilePage() {
  return (
    <Profile />
  )
}