import Insights from "@/pages/Insights";

export default function InsightsPage() {
  return (
    <Insights />
  )
}