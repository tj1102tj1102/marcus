import Transactions from "@/pages/Transactions";

export default function TransactionsPage() {
  return (
    <Transactions />
  )
}