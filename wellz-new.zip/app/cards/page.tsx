import Cards from "@/pages/Cards";

export default function CardsPage() {
  return (
    <Cards />
  )
}