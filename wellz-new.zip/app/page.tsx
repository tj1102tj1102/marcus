import Index from "@/pages/Index";

export default function Home() {
  return (
    <Index />
  );
}
