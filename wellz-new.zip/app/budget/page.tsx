import Budget from "@/pages/Budget";

export default function BudgetPage() {
  return (
    <Budget />
  )
}