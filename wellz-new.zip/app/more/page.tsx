import More from "@/pages/More";

export default function MorePage() {
  return (
    <More />
  )
}