import Transfer from "@/components/transfer/Transfer";

export default function TransferPage() {
  return (
    <Transfer />
  )
}