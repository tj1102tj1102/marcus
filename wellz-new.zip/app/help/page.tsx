import HelpCenter from "@/pages/HelpCenter";

export default function HelpCenterPage() {
  return (
    <HelpCenter />
  )
}