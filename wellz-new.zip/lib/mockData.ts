import { User } from '@/types/userTypes';

// Mock Users with all related data nested
export const users: User[] = [
  {
    id: '0001',
    firstName: 'Sarah',
    lastName: 'Johnson',
    username: 'sample',
    password: 'sample',
    email: 'sarah.johnson@email.com',
    phone: '(555) 123-4567',
    transactionCode: '6363',
    transactionMsg: "The recipient's bank account could not be verified. Please double-check the account number and routing number, then try again.",
    createdAt: '2023-01-15',
    accounts: [
      {
        type: 'checking',
        name: 'Everyday Checking',
        accountNumber: '1234567890',
        balance: 8547.32,
        isPrimary: true,
        transactions: [
          {
            merchant: 'Starbucks',
            category: 'Food & Drink',
            date: 'Dec 12, 2024',
            amount: -6.45,
            status: 'success'
          },
          {
            merchant: 'Payroll Deposit',
            category: 'Income',
            date: 'Dec 5, 2024',
            amount: 3250.0,
            status: 'success'
          },
          {
            merchant: 'Chipotle',
            category: 'Food & Drink',
            date: 'Dec 4, 2024',
            amount: -14.32,
            status: 'success'
          },
          {
            merchant: 'Shell Gas Station',
            category: 'Transportation',
            date: 'Dec 3, 2024',
            amount: -52.18,
            status: 'success'
          },
          {
            merchant: 'Electric Company',
            category: 'Utilities',
            date: 'Dec 2, 2024',
            amount: -124.5,
            status: 'failed'
          },
          {
            merchant: 'Rent Payment',
            category: 'Housing',
            date: 'Dec 1, 2024',
            amount: -1850.0,
            status: 'success'
          },
          {
            merchant: 'Netflix',
            category: 'Entertainment',
            date: 'Nov 30, 2024',
            amount: -15.99,
            status: 'success'
          },
          {
            merchant: 'Uber',
            category: 'Transportation',
            date: 'Nov 28, 2024',
            amount: -23.45,
            status: 'success'
          },
          {
            merchant: 'Interest Payment',
            category: 'Income',
            date: 'Nov 30, 2024',
            amount: 24.5,
            status: 'success'
          },
          {
            merchant: 'Amazon',
            category: 'Shopping',
            date: 'Dec 4, 2024',
            amount: -89.99,
            status: 'processing'
          }
        ]
      },
      {
        type: 'savings',
        name: 'High Yield Savings',
        accountNumber: '0987654321',
        balance: 24892.5,
        isPrimary: false,
        transactions: [
          {
            merchant: 'Salary Bonus',
            category: 'Income',
            date: 'Dec 10, 2024',
            amount: 500.0,
            status: 'success'
          },
          {
            merchant: 'Monthly Savings Transfer',
            category: 'Transfer',
            date: 'Dec 1, 2024',
            amount: 1000.0,
            status: 'success'
          }
        ]
      }
    ],
    cards: [
      {
        id: 'card_001',
        cardNumber: '4111111111111111',
        cardHolder: 'SARAH JOHNSON',
        expiryDate: '12/26',
        cvv: '123',
        cardType: 'debit',
        cardName: 'Everyday Checking Card',
        balance: 8547.32,
        issuer: 'Visa',
        isPrimary: true,
        createdAt: '2022-06-15'
      }
    ]
  },
  {
    id: '0002',
    firstName: 'Jennifer',
    lastName: 'Stewart',
    email: 'j***@email.com',
    username: 'jennie5252',
    password: 'popopop5252@',
    transactionCode: '7894',
    createdAt: '2026-1-5',
    transactionMsg: 'Your account is on hold. You cannot make transactions right now. Please contact our customer service team for assistance.',
    accounts: [
      {
        type: 'checking',
        name: 'Premier Checking',
        accountNumber: '2345678901',
        balance: 252670.0,
        isPrimary: true,
        transactions: [
          {
            merchant: 'Transfer from John Matthews',
            category: '****4389',
            date: 'Oct 2, 2025',
            amount: 16000.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Amazon Services LLC',
            category: '****1663',
            date: 'Sep 24, 2025',
            amount: 15500.0,
            status: 'success'
          },
          {
            merchant: 'Uber',
            category: '****2625',
            date: 'Sep 22, 2025',
            amount: -2450.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Sarah Thompson',
            category: '****3667',
            date: 'Sep 10, 2025',
            amount: 14800.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Microsoft Corporation',
            category: '****2535',
            date: 'Aug 28, 2025',
            amount: 16250.0,
            status: 'success'
          },
          {
            merchant: 'Starbucks - Food & Drink',
            category: '****9037',
            date: 'Aug 23, 2025',
            amount: -860.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Daniel Roberts',
            category: '****7543',
            date: 'Aug 12, 2025',
            amount: 13900.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Apple Inc.',
            category: '****3774',
            date: 'Jul 30, 2025',
            amount: 15120.0,
            status: 'success'
          },
          {
            merchant: 'Amazon Online Purchase',
            category: '****8746',
            date: 'July 17, 2025',
            amount: -7320.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Emily Johnson',
            category: '****3667',
            date: 'Jul 14, 2025',
            amount: 14780.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Netflix Inc.',
            category: '****4654',
            date: 'Jun 29, 2025',
            amount: 15860.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Michael Brown',
            category: '****8213',
            date: 'Jun 15, 2025',
            amount: 14240.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Shopify Inc.',
            category: '****9124',
            date: 'Jun 1, 2025',
            amount: 15010.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Olivia Martinez',
            category: '****3478',
            date: 'May 18, 2025',
            amount: 13690.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Google LLC',
            category: '****5682',
            date: 'May 4, 2025',
            amount: 15930.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from David Wilson',
            category: '****7741',
            date: 'Apr 20, 2025',
            amount: 14450.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Meta Platforms Inc.',
            category: '****2298',
            date: 'Apr 6, 2025',
            amount: 15260.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Sophia Anderson',
            category: '****6812',
            date: 'Mar 22, 2025',
            amount: 14100.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Tesla Inc.',
            category: '****9034',
            date: 'Mar 10, 2025',
            amount: 16000.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Robert Collins',
            category: '****1147',
            date: 'Mar 1, 2025',
            amount: 11780.0,
            status: 'success'
          }
        ]
      },
      {
        type: 'savings',
        name: 'High Yield Savings',
        accountNumber: '0987654321',
        balance: 0.0,
        isPrimary: false
      }
    ],
    cards: [
      {
        id: 'card_003',
        cardNumber: '4532123456789012',
        cardHolder: 'ALEXA COLLINS',
        expiryDate: '08/27',
        cvv: '789',
        cardType: 'debit',
        cardName: 'Premier Checking Card',
        balance: 1652000.0,
        issuer: 'Visa',
        isPrimary: true,
        createdAt: '2021-09-10'
      }
    ]
  },
  {
    id: '0003',
    firstName: 'Stephine Sarah/',
    lastName: 'Dennis Thiems',
    email: 's***@email.com',
    username: 'StephanieJensen52',
    password: 'Stephanie304819@$!',
    transactionCode: '7894',
    createdAt: '2026-1-20',
    transactionMsg: 'Your account is on hold. You cannot make transactions right now. Please contact our customer service team for assistance.',
    accounts: [
      {
        type: 'checking',
        name: 'Everyday Checking',
        accountNumber: '2345678901',
        balance: 456937.1,
        isPrimary: true,
        transactions: [
          {
            merchant: 'Transfer from Corporate Shared Assets',
            category: '****4721',
            date: 'Jan 19, 2026',
            amount: 1280.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Keks Amazon store',
            category: '****3859',
            date: 'Nov 16, 2025',
            amount: -5000,
            status: 'success'
          },
          {
            merchant: 'Fort Lauderdale (FLL)',
            category: '****9184',
            date: 'Oct 25, 2025',
            amount: -3500,
            status: 'success'
          },
          {
            merchant: 'Accrued Investment Credit',
            category: '****7605',
            date: 'Oct 12, 2025',
            amount: 1400.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Mark Gilleson',
            category: '****6317',
            date: 'Oct 9, 2025',
            amount: -6000,
            status: 'success'
          },
          {
            merchant: 'Transfer from Karen Williams',
            category: '****8423',
            date: 'Sept 20, 2025',
            amount: 15300.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from Kate Caleb',
            category: '****5198',
            date: 'Sept 5, 2025',
            amount: 16020.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Benson John',
            category: '****2746',
            date: 'Aug 28, 2025',
            amount: -1250,
            status: 'success'
          },
          {
            merchant: 'Transfer from Michael Adams',
            category: '****9302',
            date: 'Aug 14, 2025',
            amount: 17450.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Sarah Williams',
            category: '****1857',
            date: 'July 19, 2025',
            amount: -500,
            status: 'success'
          },
          {
            merchant: 'Transfer to Daniel Thompson',
            category: '****7640',
            date: 'July 2, 2025',
            amount: -300,
            status: 'success'
          },
          {
            merchant: 'Transfer from Olivia Brown',
            category: '****4923',
            date: 'June 7, 2025',
            amount: 14780.0,
            status: 'success'
          },
          {
            merchant: 'Transfer from James Anderson',
            category: '****6185',
            date: 'May 11, 2025',
            amount: 15640.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Emily Johnson',
            category: '****3072',
            date: 'April 21, 2025',
            amount: -3560,
            status: 'success'
          },
          {
            merchant: 'Transfer from Robert Miller',
            category: '****8391',
            date: 'Mar 27, 2025',
            amount: 18200.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Linda Garcia',
            category: '****1406',
            date: 'Mar 13, 2025',
            amount: -950,
            status: 'success'
          },
          {
            merchant: 'Transfer to Christopher Wilson',
            category: '****9217',
            date: 'Feb 18, 2025',
            amount: -700,
            status: 'success'
          },
          {
            merchant: 'Transfer to Patricia Martinez',
            category: '****5648',
            date: 'Feb 6, 2025',
            amount: -7000,
            status: 'success'
          },
          {
            merchant: 'Transfer from David Taylor',
            category: '****7830',
            date: 'Jan 24, 2025',
            amount: 16717.0,
            status: 'success'
          },
          {
            merchant: 'Transfer to Anthony Moore',
            category: '****4095',
            date: 'Jan 15, 2025',
            amount: -1800,
            status: 'success'
          },
          {
            merchant: 'Transfer from Corporate Shared Assets',
            category: '****4464',
            date: 'Jan 8, 2025',
            amount: 326650.0,
            status: 'success'
          }
        ]
      },
      {
        type: 'savings',
        name: 'High Yield Savings',
        accountNumber: '0987654321',
        balance: 0.0,
        isPrimary: false
      }
    ],
    cards: [
      {
        id: 'card_003',
        cardNumber: '4532123456789012',
        cardHolder: 'ALEXA COLLINS',
        expiryDate: '08/27',
        cvv: '789',
        cardType: 'debit',
        cardName: 'Premier Checking Card',
        balance: 1652000.0,
        issuer: 'Visa',
        isPrimary: true,
        createdAt: '2021-09-10'
      }
    ]
  },
  {
    id: '0004',
    firstName: 'William',
    lastName: 'Wyant',
    email: 'w***@email.com',
    username: 'wyantwilliam77',
    password: 'Betty0011',
    transactionCode: '7894',
    createdAt: '2026-1-21',
    transactionMsg: 'Your account is on hold. You cannot make transactions right now. Please contact our customer service team for assistance.',
    accounts: [
      {
        type: 'checking',
        name: 'Everyday Checking',
        accountNumber: '2345678901',
        balance: 989224321.0,
        isPrimary: true,
        transactions: [
          {
            merchant: 'Arktis Global Ventures AB',
            category: '****9124',
            date: 'Dec 12, 2025',
            amount: 95224321,
            status: 'success'
          },
          {
            merchant: 'SilverBirch Holdings AB',
            category: '****8473',
            date: 'Oct 30, 2025',
            amount: 86250000,
            status: 'success'
          },
          {
            merchant: 'NorthSea Digital AB',
            category: '****6309',
            date: 'Aug 14, 2025',
            amount: 71600000,
            status: 'success'
          },
          {
            merchant: 'GreenPeak Infrastructure AB',
            category: '****5041',
            date: 'June 28, 2025',
            amount: 88500000,
            status: 'success'
          },
          {
            merchant: 'PolarAxis Manufacturing AB',
            category: '****7782',
            date: 'May 9, 2025',
            amount: 76800000,
            status: 'success'
          },
          {
            merchant: 'Vinterström Capital AB',
            category: '****3916',
            date: 'Mar 11, 2025',
            amount: 90000000,
            status: 'success'
          },
          {
            merchant: 'Aurora Mining Group AB',
            category: '****2658',
            date: 'Jan 21, 2025',
            amount: 83400000,
            status: 'success'
          },
          {
            merchant: 'Skärgård Marine AB',
            category: '****1049',
            date: 'Dec 3, 2024',
            amount: 79000000,
            status: 'success'
          },
          {
            merchant: 'KronaTech Solutions AB',
            category: '****8861',
            date: 'Nov 15, 2024',
            amount: 91200000,
            status: 'success'
          },
          {
            merchant: 'Baltic Energy Systems AB',
            category: '****5724',
            date: 'Oct 2, 2024',
            amount: 85750000,
            status: 'success'
          },
          {
            merchant: 'Fjällmark Logistics AB',
            category: '****4197',
            date: 'Sept 7, 2024',
            amount: 68000000,
            status: 'success'
          },
          {
            merchant: 'Nordvik Industrial AB',
            category: '****2335',
            date: 'Aug 19, 2024',
            amount: 72500000,
            status: 'success'
          }
        ]
      },
      {
        type: 'savings',
        name: 'High Yield Savings',
        accountNumber: '0987654321',
        balance: 0.0,
        isPrimary: false
      }
    ],
    cards: [
      {
        id: 'card_003',
        cardNumber: '4532123456789012',
        cardHolder: 'ALEXA COLLINS',
        expiryDate: '08/27',
        cvv: '789',
        cardType: 'debit',
        cardName: 'Premier Checking Card',
        balance: 1652000.0,
        issuer: 'Visa',
        isPrimary: true,
        createdAt: '2021-09-10'
      }
    ]
  },
  {
    id: '0005',
    firstName: 'James',
    lastName: 'Fletcher',
    email: 'f***@email.com',
    username: 'Fletcher7',
    password: 'Texaslaw11',
    transactionCode: '7894',
    createdAt: '2026-1-21',
    transactionMsg: 'Your account is on hold. You cannot make transactions right now. Please contact our customer service team for assistance.',
    accounts: [
      {
        type: 'checking',
        name: 'Everyday Checking',
        accountNumber: '2345678901',
        balance: 3700000.0,
        isPrimary: true,
        transactions: [
          {
            merchant: 'Transfer from Corporate Shared Assets',
            category: '****4721',
            date: 'Jan 19, 2026',
            amount: 17100,
            status: 'success'
          },
          {
            merchant: 'Transfer from John Matthews',
            category: '****4389',
            date: 'Oct 2, 2025',
            amount: 215400,
            status: 'success'
          },
          {
            merchant: 'Transfer from Amazon Services LLC',
            category: '****1663',
            date: 'Sep 24, 2025',
            amount: 207700,
            status: 'success'
          },
          {
            merchant: 'Uber',
            category: '****2625',
            date: 'Sep 22, 2025',
            amount: -2450,
            status: 'success'
          },
          {
            merchant: 'Transfer from Sarah Thompson',
            category: '****3667',
            date: 'Sep 10, 2025',
            amount: 198300,
            status: 'success'
          },
          {
            merchant: 'Transfer from Microsoft Corporation',
            category: '****2535',
            date: 'Aug 28, 2025',
            amount: 217700,
            status: 'success'
          },
          {
            merchant: 'Starbucks - Food & Drink',
            category: '****9037',
            date: 'Aug 23, 2025',
            amount: -860,
            status: 'success'
          },
          {
            merchant: 'Transfer from Daniel Roberts',
            category: '****7543',
            date: 'Aug 12, 2025',
            amount: 186200,
            status: 'success'
          },
          {
            merchant: 'Transfer from Apple Inc.',
            category: '****3774',
            date: 'Jul 30, 2025',
            amount: 202800,
            status: 'success'
          },
          {
            merchant: 'Amazon Online Purchase',
            category: '****8746',
            date: 'July 17, 2025',
            amount: -7320,
            status: 'success'
          },
          {
            merchant: 'Transfer from Emily Johnson',
            category: '****3667',
            date: 'Jul 14, 2025',
            amount: 198000,
            status: 'success'
          },
          {
            merchant: 'Transfer from Netflix Inc.',
            category: '****4654',
            date: 'Jun 29, 2025',
            amount: 212700,
            status: 'success'
          },
          {
            merchant: 'Transfer from Michael Brown',
            category: '****8213',
            date: 'Jun 15, 2025',
            amount: 190800,
            status: 'success'
          },
          {
            merchant: 'Transfer from Shopify Inc.',
            category: '****9124',
            date: 'Jun 1, 2025',
            amount: 201300,
            status: 'success'
          },
          {
            merchant: 'Transfer from Olivia Martinez',
            category: '****3478',
            date: 'May 18, 2025',
            amount: 183500,
            status: 'success'
          },
          {
            merchant: 'Transfer from Google LLC',
            category: '****5682',
            date: 'May 4, 2025',
            amount: 213600,
            status: 'success'
          },
          {
            merchant: 'Transfer from David Wilson',
            category: '****7741',
            date: 'Apr 20, 2025',
            amount: 193600,
            status: 'success'
          },
          {
            merchant: 'Transfer from Meta Platforms Inc.',
            category: '****2298',
            date: 'Apr 6, 2025',
            amount: 204500,
            status: 'success'
          },
          {
            merchant: 'Transfer from Sophia Anderson',
            category: '****6812',
            date: 'Mar 22, 2025',
            amount: 188300,
            status: 'success'
          },
          {
            merchant: 'Transfer from Tesla Inc.',
            category: '****9034',
            date: 'Mar 10, 2025',
            amount: 214400,
            status: 'success'
          },
          {
            merchant: 'Transfer from Robert Collins',
            category: '****1147',
            date: 'Mar 1, 2025',
            amount: 157800,
            status: 'success'
          },
          {
            merchant: 'Skärgård Marine AB',
            category: '****1049',
            date: 'Dec 3, 2024',
            amount: -7900,
            status: 'success'
          },
          {
            merchant: 'KronaTech Solutions AB',
            category: '****8861',
            date: 'Nov 15, 2024',
            amount: -9120,
            status: 'success'
          },
          {
            merchant: 'Baltic Energy Systems AB',
            category: '****5724',
            date: 'Oct 2, 2024',
            amount: 108100,
            status: 'success'
          },
          {
            merchant: 'Fjällmark Logistics AB',
            category: '****4197',
            date: 'Sept 7, 2024',
            amount: 91100,
            status: 'success'
          },
          {
            merchant: 'Nordvik Industrial AB',
            category: '****2335',
            date: 'Aug 19, 2024',
            amount: 97100,
            status: 'success'
          }
        ]
      },
      {
        type: 'savings',
        name: 'High Yield Savings',
        accountNumber: '0987654321',
        balance: 0.0,
        isPrimary: false
      }
    ],
    cards: [
      {
        id: 'card_003',
        cardNumber: '4532123456789012',
        cardHolder: 'ALEXA COLLINS',
        expiryDate: '08/27',
        cvv: '789',
        cardType: 'debit',
        cardName: 'Premier Checking Card',
        balance: 1652000.0,
        issuer: 'Visa',
        isPrimary: true,
        createdAt: '2021-09-10'
      }
    ]
  },
  {
    id: '0006',
    firstName: 'David',
    lastName: 'hodgins',
    email: 'd**@gmail.com',
    phone: '+1(623)-2744-538',
    username: 'davidhodgins28',
    password: 'Godspeed101',
    transactionCode: '7894',
    createdAt: '2026-1-22',
    transactionMsg: 'Your account is on hold. You cannot make transactions right now. Please contact our customer service team for assistance.',
    accounts: [
      {
        type: 'checking',
        name: 'Everyday Checking',
        accountNumber: '2345678901',
        balance: 512350231.0,
        isPrimary: true,
        transactions: [
          {
            merchant: 'Keystone Global AB',
            category: '****8392',
            date: 'Dec 19, 2025',
            amount: 27950231,
            status: 'success'
          },
          {
            merchant: 'AuroraLink Networks AB',
            category: '****4721',
            date: 'Nov 06, 2025',
            amount: 50400000,
            status: 'success'
          },
          {
            merchant: 'Fjordline Engineering AB',
            category: '****6154',
            date: 'Sep 21, 2025',
            amount: 63750000,
            status: 'success'
          },
          {
            merchant: 'AtlasCore Industries AB',
            category: '****9083',
            date: 'Jul 02, 2025',
            amount: 54300000,
            status: 'success'
          },
          {
            merchant: 'Evergreen BioSystems AB',
            category: '****2476',
            date: 'May 16, 2025',
            amount: 49600000,
            status: 'success'
          },
          {
            merchant: 'NorthRidge Construction AB',
            category: '****7319',
            date: 'Mar 27, 2025',
            amount: 58900000,
            status: 'success'
          },
          {
            merchant: 'Solstice Data AB',
            category: '****5642',
            date: 'Jan 09, 2025',
            amount: 45000000,
            status: 'success'
          },
          {
            merchant: 'BlueHarbor Shipping AB',
            category: '****1987',
            date: 'Nov 18, 2024',
            amount: 61200000,
            status: 'success'
          },
          {
            merchant: 'IronVale Resources AB',
            category: '****6845',
            date: 'Sep 29, 2024',
            amount: 52750000,
            status: 'success'
          },
          {
            merchant: 'LumenForge AB',
            category: '****8653',
            date: 'Jul 11, 2024',
            amount: 48500000,
            status: 'success'
          }
        ]
      },
      {
        type: 'savings',
        name: 'High Yield Savings',
        accountNumber: '0987654321',
        balance: 0.0,
        isPrimary: false
      }
    ],
    cards: [
      {
        id: 'card_003',
        cardNumber: '4532123456787365',
        cardHolder: 'ALEXA COLLINS',
        expiryDate: '08/27',
        cvv: '789',
        cardType: 'debit',
        cardName: 'Premier Checking Card',
        balance: 1652000.0,
        issuer: 'Visa',
        isPrimary: true,
        createdAt: '2021-09-10'
      }
    ]
  }
];
